function inicio() {
    console.log("Había una vez una chica llamada Michelle.");
    console.log("Michelle toda su vida quería estudiar medicina.");
}

function decision(carrera) {
    if (carrera === "medicina") {
        console.log("Logré entrar a medicina y todo era felicidad.");
    } else {
        console.log("Pero la vida tenía otros planes...");
        console.log("Terminé estudiando Ingeniería en Software.");
    }
}

function tragedia() {
    console.log("Desde ese día comenzó la tragedia para ella:");

    for (let semestre = 1; semestre <= 3; semestre++) {

        if (semestre <= 4) {
            console.log("Semestre " + semestre + ": super desanimada, pensando que debí estudiar medicina.");
        } else {
            console.log("Semestre " + semestre + ": poco a poco empecé a cogerle un poquito de amor a la programación.");
        }

    }
}

function final() {
    console.log("Aunque todo parece ser una tragedia, poco a poco me voy adaptando a la programación.");
    console.log("Y entendí que por algo Dios me puso en esta carrera.");
}

inicio();
decision("software");
tragedia();
final();
